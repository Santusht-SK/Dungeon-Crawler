    #include <algorithm>
    #include <cmath>
    #include "character.h"
    
    Character::~Character() = default; // Provide a virtual destructor

    Character::Character(int HP, int AP, int DP, string name) : HP{HP}, AP{AP}, DP{DP}, maxHP{HP}, potionHP{0}, potionAP{0}, potionDP{0}, Component{name} {}

    string Character::getName() { return this->name; }
    char Character::getChar() { return this->displayName; }
    int Character::getHP() { return this->HP; }
    int Character::getDP() { return this->DP; }
    int Character::getAP() { return this->AP; }

    void Character::setHP(int change) {
        int newHP = HP + change;
        HP = min(newHP, maxHP);
    }

    void Character::setAP(int change) {
        AP = max(0, AP + change);
    }

    void Character::setDP(int change) {
        DP = max(0, DP + change);
    }

    int Character::att(Component* enemy) {
        if (enemy) {
            int damage = ceil(this->AP * 100 / (100 + enemy->getDP()));
            enemy->setHP(-1 * damage);
            return enemy->getHP();
        } else {
            cout << "bad dynamic cast for " + enemy->getName() << endl;
            return -1;
        }
    }

    int Character::getAtt(Component* enemy) {
        if (enemy) {
            int damage = ceil(enemy->getAP() * 100 / (100 + this->DP));
            this->setHP(-1 * damage);
            return damage;
        } else {
            cout << "bad dynamic cast for " + enemy->getName() << endl;
            return -1;
        }
    }