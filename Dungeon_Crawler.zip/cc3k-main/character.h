#ifndef CHARACTER_H
#define CHARACTER_H

#include "component.h"
#include <string>
#include <iostream>
#include <cmath>
#include <algorithm>

using namespace std;

class Character : public Component {
protected:
    int HP;
    int AP;
    int DP;
    int maxHP;

public:
    int potionHP;
    int potionAP;
    int potionDP;
    virtual ~Character(); // Provide a virtual destructor
    Character(int HP, int AP, int DP, string name);

    string getName() override;
    char getChar() override;
    int getHP() override;
    int getDP() override;
    int getAP() override;

    void setHP(int change) override;

    void setAP(int change) override;

    void setDP(int change) override;

    virtual int att(Component* enemy) override;

    virtual int getAtt(Component* enemy) override;
};

#endif // CHARACTER_H

