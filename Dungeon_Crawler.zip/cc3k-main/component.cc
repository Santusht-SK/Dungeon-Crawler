#include "component.h"

Component::Component(string name) : name{name}
{
    if (name == "hWall")
    {
        displayName = '-';
    }
    else if (name == "vWall")
    {
        displayName = '|';
    }
    else if (name == "tile")
    {
        displayName = '.';
    }
    else if (name == "doorway")
    {
        displayName = '+';
    }
    else if (name == "passage")
    {
        displayName = '#';
    }
    else if (name == "stair")
    {
        displayName = '\\';
    }
    else if (name == "PH" || name == "RH" || name == "WA" || name == "WD" || name == "BA" || name == "BD")
    {
        displayName = 'P';
    }
    else if (name == "smallHoard" || name == "normal" || name == "merchantHoard" || name == "dragonHoard")
    {
        displayName = 'G';
    }
}