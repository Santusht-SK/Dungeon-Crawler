#ifndef COMPONENT_H
#define COMPONENT_H

#include <string>
#include <iostream>

using namespace std;

class Component {
protected:
    string name;
    char displayName;

public:
    int potionHP = 0;
    int potionAP = 0;
    int potionDP = 0;
    bool isMoved = false;
    int goldValue = 0;
    Component* dragonProtector = nullptr;
    virtual ~Component() = default; // Provide a virtual destructor
    Component(string name);
        
    

    virtual string getName() { return name; }
    virtual char getChar() { return displayName; }
    virtual int getHP() { return 0; }
    virtual int getAP() { return 0; }
    virtual int getDP() { return 0; }
    virtual void setHP(int change) {}
    virtual void setAP(int change) {}
    virtual void setDP(int change) {}
    virtual int att(Component* enemy) { return 0; }
    virtual int getAtt(Component* enemy) { return 0; }
};

#endif // COMPONENT_H
