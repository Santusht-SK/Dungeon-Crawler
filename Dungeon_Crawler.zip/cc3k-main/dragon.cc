#include "dragon.h"

Dragon::Dragon() : Character(150, 20, 20, "dragon")
{
    this->displayName = 'D';
}