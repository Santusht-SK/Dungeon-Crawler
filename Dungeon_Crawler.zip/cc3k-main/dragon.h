#ifndef DRAGON
#define DRAGON
#include "component.h"
#include "character.h"
 // will defeine this later

class Dragon: public Character {
    public:
        Dragon(); // default constructor
};









#endif


