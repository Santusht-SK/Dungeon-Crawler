#include "drow.h"

Drow::Drow() : Character(150, 25, 15, "Drow")
{
    this->displayName = '@';
}

int Drow::att(Component *enemy)
{
    Character *temp = dynamic_cast<Character *>(enemy);
    if (temp)
    {
        int damage = ceil(this->AP * 100 / (100 + temp->getDP()));
        temp->setHP(-1 * damage);
        return temp->getHP();
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of
  // pick up gold, modify setttings.

int Drow::getAtt(Component *enemy)
{
    
    if (enemy)
    {
        int damage = ceil(enemy->getAP() * 100 / (100 + this->DP));
        this->setHP(-1 * damage);
        return damage;
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // get attack only called when enemy didnt miss, the random miss function should be judged by main.cc