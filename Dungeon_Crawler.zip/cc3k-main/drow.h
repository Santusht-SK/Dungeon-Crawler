#ifndef DROW_H
#define DROW_H
#include "component.h"
#include "character.h"
#include <cmath>
#include <iostream>
using namespace ::std;

class Drow : public Character
{
public:
    Drow();

    int att(Component *enemy) override;
     // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of
    // pick up gold, modify setttings.

    int getAtt(Component *enemy) override;
     // get attack only called when enemy didnt miss, the random miss function should be judged by main.cc
};

#endif
