#include "dwarf.h"
Dwarf::Dwarf() : Character(100, 20, 30, "dwarf")
{
    this->displayName = 'W';
}