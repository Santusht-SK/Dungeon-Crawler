#ifndef DWARF
#define DWARF
#include "character.h"
#include "component.h"

class Dwarf: public Character {
    public: 
        Dwarf();
};




#endif

