#include "elf.h"

Elf::Elf() : Character(140, 30, 10, "elf")
{
    this->displayName = 'E';
}