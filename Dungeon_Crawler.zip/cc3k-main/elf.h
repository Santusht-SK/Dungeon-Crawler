#ifndef ELF
#define ELF
#include "character.h"
#include "component.h"
class Elf: public Character {
    public:
        Elf();
};






#endif

