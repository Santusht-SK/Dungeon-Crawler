#include "floor.h"
#include <vector>
#include <memory>
#include <utility>
#include <cstdlib>
using namespace std;
Floor::Floor()
{
    for (int i = 0; i < rowNum; i++)
    {
        for (int j = 0; j < colNum; j++)
        {
            data[i][j] = make_unique<Component>("vWall");
        }
    }
}
Floor::Floor(ifstream &file)
{
    for (int i = 0; i < rowNum; i++)
    {
        for (int j = 0; j < colNum; j++)
        {
            char c;
            file >> noskipws >> c;
            if (c == '|')
            {
                data[i][j] = make_unique<Component>("vWall");
            }
            else if (c == '-')
            {
                data[i][j] = make_unique<Component>("hWall");
            }
            else if (c == '.')
            {
                data[i][j] = make_unique<Component>("tile");
            }
            else if (c == '+')
            {
                data[i][j] = make_unique<Component>("doorway");
                doorwayPos.push_back(make_pair(i, j));
            }
            else if (c == '#')
            {
                data[i][j] = make_unique<Component>("passage");
                passagePos.push_back(make_pair(i, j));
            }
            else if (c == '/')
            {
                data[i][j] = make_unique<Component>("stair");
            }
            else if (c == '@')
            {
                data[i][j] = make_unique<Shade>();
            }
            else if (c == 'E')
            {
                data[i][j] = make_unique<Elf>();
            }
            else if (c == 'W')
            {
                data[i][j] = make_unique<Dwarf>();
            }
            else if (c == 'O')
            {
                data[i][j] = make_unique<Orc>();
            }
            else if (c == 'M')
            {
                data[i][j] = make_unique<Merchant>();
            }
            else if (c == '0')
            {
                data[i][j] = make_unique<Component>("RH");
            }
            else if (c == '1')
            {
                data[i][j] = make_unique<Component>("BA");
            }
            else if (c == '2')
            {
                data[i][j] = make_unique<Component>("BD");
            }
            else if (c == '3')
            {
                data[i][j] = make_unique<Component>("PH");
            }
            else if (c == '4')
            {
                data[i][j] = make_unique<Component>("WA");
            }
            else if (c == '5')
            {
                data[i][j] = make_unique<Component>("WD");
            }
            else if (c == '6')
            {
                data[i][j] = make_unique<Component>("normal");
                data[i][j]->goldValue = 2;
            }
            else if (c == '7')
            {
                data[i][j] = make_unique<Component>("smallHoard");
                data[i][j]->goldValue = 1;
            }
            else if (c == '8')
            {
                data[i][j] = make_unique<Component>("merchantHoard");
                data[i][j]->goldValue = 4;
            }
            else if (c == '9')
            {
                data[i][j] = make_unique<Component>("dragonHoard");
                data[i][j]->goldValue = 6;
            }
        }
        char c;
        file >> noskipws >> c; // MUST HAVE THIS TO SKIP '\n'
    }

    for (int i = 3; i < 7; i++)
    {
        for (int j = 3; j < 29; j++)
        {
            chamberTopLeft.push_back(make_pair(i, j));
        }
    } // create chamberTopLeft and fill it with tile

    for (int i = 15; i < 22; i++)
    {
        for (int j = 4; j < 25; j++)
        {
            chamberBottomLeft.push_back(make_pair(i, j));
        }
    } // create chamberBottomLeft

    for (int i = 10; i < 13; i++)
    {
        for (int j = 38; j < 50; j++)
        {
            chamberMiddle.push_back(make_pair(i, j));
        }
    } // create chamberMiddle

    for (int i = 3; i < 5; i++)
    {
        for (int j = 39; j < 62; j++)
        {
            chamberTopRight.push_back(make_pair(i, j));
        }
    }

    for (int j = 39; j < 70; j++)
    {
        chamberTopRight.push_back(make_pair(5, j));
    }

    for (int j = 39; j < 73; j++)
    {
        chamberTopRight.push_back(make_pair(6, j));
    }

    for (int i = 7; i < 13; i++)
    {
        for (int j = 61; j < 76; j++)
        {
            chamberTopRight.push_back(make_pair(i, j));
        }
    } // create chamberTopRight

    for (int i = 16; i < 19; i++)
    {
        for (int j = 65; j < 76; j++)
        {
            chamberBottomRight.push_back(make_pair(i, j));
        }
    }

    for (int i = 19; i < 22; i++)
    {
        for (int j = 37; j < 76; j++)
        {
            chamberBottomRight.push_back(make_pair(i, j));
        }
    } // create chamberBottomRight
}

pair<int, int> Floor::getPosition(vector<pair<int, int>> &chamber)
{
    while (true)
    {
        int idx = rand() % chamber.size();
        if (data[chamber[idx].first][chamber[idx].second]->getChar() == '.')
            return chamber[idx];
    }

    for (int i = 3; i < 7; i++)
    {
        for (int j = 3; j < 29; j++)
        {
            chamberTopLeft.push_back(make_pair(i, j));
        }
    } // create chamberTopLeft and fill it with tile

    for (int i = 15; i < 22; i++)
    {
        for (int j = 4; j < 25; j++)
        {
            chamberBottomLeft.push_back(make_pair(i, j));
        }
    } // create chamberBottomLeft

    for (int i = 10; i < 13; i++)
    {
        for (int j = 38; j < 50; j++)
        {
            chamberMiddle.push_back(make_pair(i, j));
        }
    } // create chamberMiddle

    for (int i = 3; i < 5; i++)
    {
        for (int j = 39; j < 62; j++)
        {
            chamberTopRight.push_back(make_pair(i, j));
        }
    }

    for (int j = 39; j < 70; j++)
    {
        chamberTopRight.push_back(make_pair(5, j));
    }

    for (int j = 39; j < 73; j++)
    {
        chamberTopRight.push_back(make_pair(6, j));
    }

    for (int i = 7; i < 13; i++)
    {
        for (int j = 61; j < 76; j++)
        {
            chamberTopRight.push_back(make_pair(i, j));
        }
    } // create chamberTopRight

    for (int i = 16; i < 19; i++)
    {
        for (int j = 65; j < 76; j++)
        {
            chamberBottomRight.push_back(make_pair(i, j));
        }
    }

    for (int i = 19; i < 22; i++)
    {
        for (int j = 37; j < 76; j++)
        {
            chamberBottomRight.push_back(make_pair(i, j));
        }
    } // create chamberBottomRight
}

bool Floor::isStaircase()
{
    if (playerPos == staircasePos) {
        return true;
    }
    return false;
}
bool Floor::isValidPosition(pair<int, int> pos)
{
    return (data[pos.first][pos.second] && data[pos.first][pos.second]->getChar() == '.');
}

void Floor::createPotions()
{
    vector<vector<pair<int, int>> *> chambers;
    chambers.push_back(&chamberTopLeft);
    chambers.push_back(&chamberTopRight);
    chambers.push_back(&chamberBottomLeft);
    chambers.push_back(&chamberBottomRight);
    chambers.push_back(&chamberMiddle);
    const int totalNumPotions = 10;
    vector<string> potionTypes;
    potionTypes.push_back("BA");
    potionTypes.push_back("BD");
    potionTypes.push_back("PH");
    potionTypes.push_back("RH");
    potionTypes.push_back("WA");
    potionTypes.push_back("WD");
    for (int i = 0; i < totalNumPotions; i++)
    {
        int chamberIdx = rand() % 5;
        // if more potions are added this acounts for it
        int potionTypesIdx = rand() % potionTypes.size();
        pair<int, int> pos = getPosition(*chambers[chamberIdx]);
        string potionTypeStr = potionTypes[potionTypesIdx];

        if (potionTypeStr == "BA")
        {
            data[pos.first][pos.second] = make_unique<Component>("BA");
        }
        else if (potionTypeStr == "BD")
        {
            data[pos.first][pos.second] = make_unique<Component>("BD");
        }
        else if (potionTypeStr == "PH")
        {
            data[pos.first][pos.second] = make_unique<Component>("PH");
        }
        else if (potionTypeStr == "RH")
        {
            data[pos.first][pos.second] = make_unique<Component>("RH");
        }
        else if (potionTypeStr == "WA")
        {
            data[pos.first][pos.second] = make_unique<Component>("WA");
        }
        else
        {
            data[pos.first][pos.second] = make_unique<Component>("WD");
        }
    }
}

vector<pair<int, int>> Floor::Neighbors(pair<int, int> pos)
{
    vector<pair<int, int>> neighbors = {
        make_pair(pos.first - 1, pos.second - 1),
        make_pair(pos.first - 1, pos.second),
        make_pair(pos.first - 1, pos.second + 1),
        make_pair(pos.first, pos.second - 1),
        make_pair(pos.first, pos.second + 1),
        make_pair(pos.first + 1, pos.second - 1),
        make_pair(pos.first + 1, pos.second),
        make_pair(pos.first + 1, pos.second + 1)};
    return neighbors;
}

bool Floor::lookForPotion()
{
    vector<pair<int, int>> neighbours = Neighbors(playerPos);
    for (int i = 0; i < 8; i++)
    {
        if (data[neighbours[i].first][neighbours[i].second] && data[neighbours[i].first][neighbours[i].second]->getChar() == 'P')
        {
            return true;
        }
    }

    return false;
}

void Floor::createGold()
{
    vector<vector<pair<int, int>> *> chambers;
    chambers.push_back(&chamberTopLeft);
    chambers.push_back(&chamberTopRight);
    chambers.push_back(&chamberBottomLeft);
    chambers.push_back(&chamberBottomRight);
    chambers.push_back(&chamberMiddle);
    const int totalNumGold = 10;
    for (int i = 0; i < totalNumGold; i++)
    {
        int chamberIdx = rand() % 5;
        // if more potions are added this acounts for it
        pair<int, int> pos = getPosition(*chambers[chamberIdx]);
        int goldType = rand() % 8;
        if (goldType < 5)
        {
            data[pos.first][pos.second] = make_unique<Component>("normal");
            data[pos.first][pos.second]->goldValue = 2;
        }
        else if (goldType < 7)
        {
            data[pos.first][pos.second] = make_unique<Component>("smallHoard");
            data[pos.first][pos.second]->goldValue = 1;
        }
        else
        {
            data[pos.first][pos.second] = make_unique<Component>("dragonHoard");
            data[pos.first][pos.second]->goldValue = 6;
            vector<pair<int, int>> neighbors = Neighbors(pos);
            while (true)
            {
                int ranum = rand() % 8;
                if (isValidPosition(neighbors[ranum]))
                {
                    data[neighbors[ranum].first][neighbors[ranum].second] = make_unique<Dragon>();
                    data[pos.first][pos.second]->dragonProtector = data[neighbors[ranum].first][neighbors[ranum].second].get(); // dragonHoafd has a pointer to the dragon protecting it
                    break;
                }
            }
        }
    }
}

void Floor::createStairs(string characterType)
{
    vector<vector<pair<int, int>> *> chambers;
    chambers.push_back(&chamberTopLeft);
    chambers.push_back(&chamberTopRight);
    chambers.push_back(&chamberBottomLeft);
    chambers.push_back(&chamberBottomRight);
    chambers.push_back(&chamberMiddle);

    int chamberIdx = rand() % 5;
    pair<int, int> pos = getPosition(*chambers[chamberIdx]);
    data[pos.first][pos.second] = make_unique<Component>("stair");

    createPlayer(chamberIdx, characterType);
}

void Floor::createPlayer(int idx, string characterType)
{
    vector<vector<pair<int, int>> *> chambers;
    if (idx != 0)
        chambers.push_back(&chamberTopLeft);
    if (idx != 1)
        chambers.push_back(&chamberTopRight);
    if (idx != 2)
        chambers.push_back(&chamberBottomLeft);
    if (idx != 3)
        chambers.push_back(&chamberBottomRight);
    if (idx != 4)
        chambers.push_back(&chamberMiddle);

    int chamberIdx = rand() % 4;
    pair<int, int> pos = getPosition(*chambers[chamberIdx]);
    if (characterType == "s")
        data[pos.first][pos.second] = make_unique<Shade>();
    else if (characterType == "d")
        data[pos.first][pos.second] = make_unique<Drow>();
    else if (characterType == "v")
        data[pos.first][pos.second] = make_unique<Vampire>();
    else if (characterType == "g")
        data[pos.first][pos.second] = make_unique<Goblin>();
    else if (characterType == "t")
        data[pos.first][pos.second] = make_unique<Troll>();

    playerPos = pos;
}

void Floor::spawnEnemies()
{
    for (int i = 0; i < 20; i++)
    {
        unique_ptr<Component> enemy;
        int enemyType = rand() % 18;
        if (enemyType < 4)
        {
            enemy = make_unique<Human>();
        }
        else if (enemyType < 7)
        {
            enemy = make_unique<Dwarf>();
        }
        else if (enemyType < 12)
        {
            enemy = make_unique<Halfling>();
        }
        else if (enemyType < 14)
        {
            enemy = make_unique<Elf>();
        }
        else if (enemyType < 16)
        {
            enemy = make_unique<Orc>();
        }
        else
        {
            enemy = make_unique<Merchant>();
        }
        while (true)
        {
            int row = rand() % rowNum;
            int col = rand() % colNum;
            if (data[row][col] && data[row][col]->getChar() == '.')
            {
                data[row][col] = move(enemy);
                break;
            }
        }
    }
}

int Floor::printFloor()
{   int goldCollected = 0;
    for (int i = 0; i < rowNum; i++)
    {
        for (int j = 0; j < colNum; j++)
        {
            if (data[i][j] == nullptr) {
                cout << " ";
            }
            else {

                if ((data[i][j]->getChar() == 'H' || data[i][j]->getChar() == 'W' || data[i][j]->getChar() == 'E' || data[i][j]->getChar() == 'O' 
                || data[i][j]->getChar() == 'M' || data[i][j]->getChar() == 'L' || data[i][j]->getChar() == 'D' ) && data[i][j]->getHP() <= 0) {
                    if (data[i][j]->getChar() == 'M') {
                        data[i][j] = make_unique<Component>("merchantHoard");
                        data[i][j]->goldValue = 4;
                    }
                    else if(data[i][j]->getChar() == 'H'){
                        data[i][j] = make_unique<Component>("normal");
                        data[i][j]->goldValue = 4;
                    }

                    else {
                        if (data[i][j]->getChar() != 'D') {
                            int random = rand() % 2;
                            if (random == 1) {
                                goldCollected += 1;
                            }
                            else {
                                goldCollected += 2;
                            }
                        }
                        data[i][j] = make_unique<Component>("tile");
                    }
                }
                else if (data[i][j] && data[i][j]->getChar() != '@' && std::find(doorwayPos.begin(), doorwayPos.end(), make_pair(i, j)) != doorwayPos.end())
                {
                    data[i][j] = make_unique<Component>("doorway");  
                }
                else if (data[i][j] && data[i][j]->getChar() != '@' && std::find(passagePos.begin(), passagePos.end(), make_pair(i, j)) != passagePos.end())
                {
                    data[i][j] = make_unique<Component>("passage");
                }   

                cout << data[i][j]->getChar();
            }
            if (data[i][j] && data[i][j]->getChar() == '\\')
            {
                staircasePos.first = i;
                staircasePos.second = j;
        
            }
        }
        cout << endl;
    }
    return goldCollected;
}

int Floor::movePlayer(string direction)
{
    int row = playerPos.first;
    int col = playerPos.second;
    int x = 0, y = 0;
    if (direction == "no")
    {
        x = -1;
    }
    else if (direction == "so")
    {
        x = 1;
    }
    else if (direction == "ea")
    {
        y = 1;
    }
    else if (direction == "we")
    {
        y = -1;
    }
    else if (direction == "ne")
    {
        x = -1;
        y = 1;
    }
    else if (direction == "nw")
    {
        x = -1;
        y = -1;
    }
    else if (direction == "se")
    {
        x = 1;
        y = 1;
    }
    else if (direction == "sw")
    {
        x = 1;
        y = -1;
    }
    if (walkable(make_pair(row + x, col + y)))
    {

        if (data[row + x][col + y]->getName() == "dragonHoard" && data[row + x][col + y]->dragonProtector && data[row + x][col + y]->dragonProtector->getHP() > 0)
        {
            cout << "Dragon is protecting the dragon hoard, you cannot pick up the gold" << endl;
            return 0;
        }

        else if (data[row + x][col + y]->getChar() == 'G')
        {
            int value = data[row + x][col + y]->goldValue;
            data[row + x][col + y] = move(data[row][col]);
            data[row][col] = make_unique<Component>("tile");
            playerPos = make_pair(row + x, col + y);
            return value;
        }
        else
        {
            swap(data[row][col], data[row + x][col + y]);
            data[row][col] = make_unique<Component>("tile"); // WE WILL FIX THIS BUG LATER
            playerPos = make_pair(row + x, col + y);
            return 0;
        }
    }
    return 0;
}

void Floor::moveEnemiesRandomly()
{
    for (int i = 0; i < rowNum; i++)
    {
        for (int j = 0; j < colNum; j++)
        {
            if (data[i][j] && data[i][j]->isMoved == false && (data[i][j]->getChar() == 'H' || data[i][j]->getChar() == 'W' || data[i][j]->getChar() == 'E' || data[i][j]->getChar() == 'O' || data[i][j]->getChar() == 'M' || data[i][j]->getChar() == 'L'))
            {

                vector<pair<int, int>> neighbors = Neighbors(make_pair(i, j));

                while (true)
                {
                    int randNum = rand() % 8;
                    if (isValidPosition(neighbors[randNum]))
                    {

                        data[i][j]->isMoved = true;

                        // std::swap(data[i][j], data[neighbors[randNum].first][neighbors[randNum].second]);
                        data[neighbors[randNum].first][neighbors[randNum].second] = move(data[i][j]);

                        data[i][j] = make_unique<Component>("tile");

                        break;
                    }
                }
            }
        }
    }
    for (int i = 0; i < rowNum; i++)
    {
        for (int j = 0; j < colNum; j++)
        {
            if (data[i][j])
            {
                data[i][j]->isMoved = false;
            }
        }
    }
}

string Floor::drinkPotion(pair<int, int> potion)
{
    bool isDrow = data[playerPos.first][playerPos.second]->getName() == "Drow";

    if (data[potion.first][potion.second]->getName() == "RH")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setHP(15);
            data[playerPos.first][playerPos.second]->potionHP += 15;
        }
        else
        {
            data[playerPos.first][playerPos.second]->setHP(10);
            data[playerPos.first][playerPos.second]->potionHP += 10;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses RH";
    }
    else if (data[potion.first][potion.second]->getName() == "BA")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setAP(8);      // rounded up
            data[playerPos.first][playerPos.second]->potionAP += 8; // rounded up
        }
        else
        {
            data[playerPos.first][playerPos.second]->setAP(5);
            data[playerPos.first][playerPos.second]->potionAP += 5;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses BA";
    }
    else if (data[potion.first][potion.second]->getName() == "BD")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setDP(8);      // rounded up
            data[playerPos.first][playerPos.second]->potionDP += 8; // rounded up
        }
        else
        {
            data[playerPos.first][playerPos.second]->setDP(5);
            data[playerPos.first][playerPos.second]->potionDP += 5;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses BD";
    }
    else if (data[potion.first][potion.second]->getName() == "PH")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setHP(-15);
            data[playerPos.first][playerPos.second]->potionHP -= 15;
        }
        else
        {
            data[playerPos.first][playerPos.second]->setHP(-10);
            data[playerPos.first][playerPos.second]->potionHP -= 10;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses PH";
    }
    else if (data[potion.first][potion.second]->getName() == "WA")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setAP(-8);     // rounded up
            data[playerPos.first][playerPos.second]->potionAP -= 8; // rounded up
        }
        else
        {
            data[playerPos.first][playerPos.second]->setAP(-5);
            data[playerPos.first][playerPos.second]->potionAP -= 5;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses WA";
    }
    else if (data[potion.first][potion.second]->getName() == "WD")
    {
        if (isDrow)
        {
            data[playerPos.first][playerPos.second]->setDP(-8);     // rounded up
            data[playerPos.first][playerPos.second]->potionDP -= 8; // rounded up
        }
        else
        {
            data[playerPos.first][playerPos.second]->setDP(-5);
            data[playerPos.first][playerPos.second]->potionDP -= 5;
        }
        data[potion.first][potion.second] = make_unique<Component>("tile");
        return "PC uses WD";
    }
} // helper function for usePotion, we only need to call usePotion

string Floor::usePotion(string direction)
{
    int row = playerPos.first;
    int col = playerPos.second;
    if (direction == "no")
    {
        if (data[row - 1][col] && (data[row - 1][col]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row - 1, col)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "so")
    {
        if (data[row + 1][col] && (data[row + 1][col]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row + 1, col)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "ea")
    {
        if (data[row][col + 1] && (data[row][col + 1]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row, col + 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "we")
    {
        if (data[row][col - 1] && (data[row][col - 1]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row, col - 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "ne")
    {
        if (data[row - 1][col + 1] && (data[row - 1][col + 1]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row - 1, col + 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "nw")
    {
        if (data[row - 1][col - 1] && (data[row - 1][col - 1]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row - 1, col - 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "se")
    {
        if (data[row + 1][col + 1] && (data[row + 1][col + 1]->getChar() == 'P'))
        {
            return (drinkPotion(make_pair(row + 1, col + 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else if (direction == "sw")
    {
        if (data[row + 1][col - 1] && (data[row + 1][col - 1])->getChar() == 'P')
        {
            return (drinkPotion(make_pair(row + 1, col - 1)));
        }
        else
        {
            return ("No potion there");
        }
    }
    else
    {
        return ("Invalid move, try again!");
    }
}

bool Floor::walkable(pair<int, int> pos)
{
    return (data[pos.first][pos.second] && (data[pos.first][pos.second]->getChar() == '.' || data[pos.first][pos.second]->getChar() == '+' || data[pos.first][pos.second]->getChar() == '#' || data[pos.first][pos.second]->getChar() == '\\' || data[pos.first][pos.second]->getChar() == 'G'));
}

string Floor::getFight(bool isHated)
{
    
    int row = playerPos.first;
    int col = playerPos.second;
    vector<pair<int, int>> neighbors = Neighbors(playerPos);
    for (int x = -1; x <= 1; x++)
    {
        for (int y = -1; y <= 1; y++)
        {
            if (data[row + x][col + y] && (data[row + x][col + y]->getChar() == 'H' || data[row + x][col + y]->getChar() == 'W' || data[row + x][col + y]->getChar() == 'E' || data[row + x][col + y]->getChar() == 'O' || (data[row + x][col + y]->getChar() == 'M' && isHated) || data[row + x][col + y]->getChar() == 'L' || data[row + x][col + y]->getChar() == 'D' ||
                                           (data[row + x][col + y]->getName() == "dragonHoard" && data[row + x][col + y]->dragonProtector && data[row + x][col + y]->dragonProtector->getHP() > 0)))
            {
                string s = "A";
                int miss = rand() % 2;
                if (miss == 0)
                {
                    Component *enemy;
                    if (data[row + x][col + y]->getName() == "dragonHoard")
                    {
                        enemy = data[row + x][col + y]->dragonProtector;
                    }
                    else
                    {
                        enemy = data[row + x][col + y].get();
                    }
                    int damage = data[row][col]->getAtt(enemy);
                    s += " " + data[row + x][col + y]->getName() + " attacked you for " + to_string(damage) + " damage";
                    return s;
                }
                s = data[row + x][col + y]->getName() + " missed an attack!";
                return s;
            }
        }
    }
    return "A";
}


            

string Floor::goFight(string direction, int attMerchant) {
    string s;
    int row = playerPos.first;
    int col = playerPos.second;
    int x = 0;
    int y = 0;
    if (direction == "no") {
        x = -1;
    } else if (direction == "so") {
        x = 1;
    } else if (direction == "ea") {
        y = 1;
    } else if (direction == "we") {
        y = -1;
    } else if (direction == "ne") {
        x = -1;
        y = 1;
    } else if (direction == "nw") {
        x = -1;
        y = -1;
    } else if (direction == "se") {
        x = 1;
        y = 1;
    } else if (direction == "sw") {
        x = 1;
        y = -1;
    }
    if(data[row + x][col + y] && data[row + x][col + y]->getChar() == 'M' && attMerchant == 1) {
        return "Merchant";
       
    }
    else if (data[row + x][col + y] && attMerchant == 0 && (data[row + x][col + y]->getChar() == 'H' || data[row + x][col + y]->getChar() == 'W' || data[row + x][col + y]->getChar() == 'E' || data[row + x][col + y]->getChar() == 'O' 
    || data[row + x][col + y]->getChar() == 'M' || data[row + x][col + y]->getChar() == 'L' || data[row + x][col + y]->getChar() == 'D')) {
        if (data[row + x][col + y]->getChar() == 'E' && data[row][col]->getName() != "Drow") {
            data[row][col]->att(data[row + x][col + y].get());
            data[row][col]->att(data[row + x][col + y].get());
            string HP = std::to_string(data[row + x][col + y]->getHP());
            return "attacked elf twice, " "elf have " + HP + "HP"; 
        }
        else if (data[row + x][col + y]->getChar() == 'L') {
            int random = rand() % 2;
            if (random == 0) {
                return "missed attack to Halfling";
            }
            else {
                     data[row][col]->att(data[row + x][col + y].get());
                     string HP = std::to_string(data[row + x][col + y]->getHP());
                    return "attacked Halfling, " "halfling have " + HP + "HP"; 
            }
        }
        else {
            data[row][col]->att(data[row + x][col + y].get());
            string HP = std::to_string(data[row + x][col + y]->getHP());
            if (data[row + x][col + y]->getChar() == 'M') {
                return "attacked" + data[row + x][col + y]->getName() + HP + "HP, Merchants are hostile!";
            }
            return "attacked " + data[row + x][col + y]->getName() + "it has " + HP + " HP left";
        }
    }
    else {
        return "";
    }
}

bool Floor::attackedMerchant(string direction) {
     if (goFight(direction, 1) == "Merchant") {
        return true;
     }
     else {
        return false;
     }
}





