#ifndef FLOOR
#define FLOOR
#include <utility>
#include <vector>
#include <memory>
#include <iostream>
#include <fstream>
#include <string>
#include "component.h"
#include "character.h"
#include "drow.h"
#include "vampire.h"
#include "shade.h"
#include "troll.h"
#include "goblin.h"
#include "dragon.h"
#include "dwarf.h"
#include "halfling.h"
#include "human.h"
#include "merchant.h"
#include "orc.h"
#include "elf.h"
using namespace ::std;

/*READ!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  Naming rules
    hWall for '-'
    vWall for '|'
    tile for '.'
    doorway for '+'
    passage for '#'
    stair for '/'
    for all enemies and player characters it start with uncapitalized letter e.g. "vampire"   NOTTTT "Vampire"
    The way to check if something is a tile or wall is to compare the component->name.
    PH for potion of health
    RH for potion of restore health
    BA for potion of boost attack
    BD for potion of boost defense
    WA for potion of wound attack
    WD for potion of wound defense
    noraml for normal pile of gold value is 2
    smallHoard for smallHoard pile of gold value is 1
    merchantHoard for merchant hoard pile of gold value is 4
    dragonHoard for dragon hoard pile of gold value is 6
*/

class Floor
{
public:
    vector<pair<int, int>> passagePos; // record all positions for passages, this will be useful for random generating
    vector<pair<int, int>> doorwayPos; // record all positions for doorways, this will be useful for random generating

    static const int rowNum = 25; // theres 25 rows in totzl
    static const int colNum = 79; // theres 79 cols in total
    std::unique_ptr<Component> data[rowNum][colNum];
    vector<pair<int, int>> chamberTopLeft; // record all positions for chamber 1, this will be useful for random generating
    vector<pair<int, int>> chamberTopRight;
    vector<pair<int, int>> chamberBottomLeft;
    vector<pair<int, int>> chamberBottomRight;
    vector<pair<int, int>> chamberMiddle;



    vector<pair<int, int>> allPosiblePos; // including pos for all tiles and passages

    Floor();

    pair<int, int> playerPos;
    pair<int, int> staircasePos;

    Floor(ifstream &file);

    int printFloor();

    void spawnEnemies();

    void createPotions();

    void createStairs(string characterType);

    void createPlayer(int idx, string characterType);

    void createGold();

    string getFight(bool isHated);

    vector<pair<int, int>> Neighbors(pair<int, int> pos); 

    pair<int, int> getPosition(vector<pair<int, int>> &chamber);

    string usePotion(string direction);

    bool isValidPosition(pair<int, int> pos);

    bool walkable(pair<int, int> pos);

    int movePlayer(string direction);

    void moveEnemiesRandomly();

    string drinkPotion(pair<int, int> potion); //helper function for usePotion, We only call usePotion in main.cc

    bool lookForPotion();

    string goFight(string direction, int attMerchant);

    bool isStaircase();

    bool attackedMerchant(string direction);

};

#endif
