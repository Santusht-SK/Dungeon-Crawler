#include "game.h"

Game::Game() : canEnemiesMove(true), isHated(false), currentFloor(0), gold(0)
{   
    string characterType;
    getline(cin, characterType);
    if (characterType.empty())
    {
        characterType = "s";
    }

    for (int i = 0; i < 5; ++i)
    {
        std::ifstream file("emptyfloor.txt");
        Floor f(file);
        f.spawnEnemies();
        f.createGold();
        f.createPotions();
        f.createStairs(characterType);
        floors.emplace_back(move(f));
    }
}
void Game::nextFloor()
{
    if (currentFloor < floors.size() - 1)
    {
        ++currentFloor;
    }
}

int Game::getGold()
{
    return gold;
}

void Game::setGold(int goldAmount)
{
    gold += goldAmount;
}

bool Game::processCmdMovement(const std::string &command)
{
    int x = 0, y = 0;
    if (command == "no")
    {
        x = -1;
    }
    else if (command == "so")
    {
        x = 1;
    }
    else if (command == "ea")
    {
        y = 1;
    }
    else if (command == "we")
    {
        y = -1;
    }
    else if (command == "ne")
    {
        x = -1;
        y = 1;
    }
    else if (command == "nw")
    {
        x = -1;
        y = -1;
    }
    else if (command == "se")
    {
        x = 1;
        y = 1;
    }
    else if (command == "sw")
    {
        x = 1;
        y = -1;
    }
    pair<int, int> newPos = {floors[currentFloor].playerPos.first + x, floors[currentFloor].playerPos.second + y};
    if (floors[currentFloor].walkable(newPos))
    {
        setGold(floors[currentFloor].movePlayer(command));
        return true;
        // cout << "Action: PC moves " << command << endl;
    }
    return false;
}
void Game::isWon()
{
    if (floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getName() == "Drow")
    {
        cout << "You won! Your final score is : " << getGold() * 1.5 << endl;
    }
    else
    {
        cout << "You won! Your final score is : " << getGold() << endl;
    }
}

void Game::isLost()
{
    if (f.data[f.playerPos.first][f.playerPos.second]->getName() == "Shade")
    {
        cout << "You Lost... Your final score is : " << getGold() * 1.5 << endl;
    }
    else
    {
        cout << "You Lost... Your final score is : " << getGold() << endl;
    }
}

void Game::runGame()
{
    int maxHP = floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getHP();
    bool firstMove = true;
    string action;

    while (true)
    {
        cout << "Level: " << currentFloor + 1 << endl;
        if (currentFloor >= floors.size() - 1)
        {
            isWon();
            break;
        }

        setGold(floors[currentFloor].printFloor());
        if (!firstMove)
        {
            string temp = floors[currentFloor].getFight(isHated);
            if (temp != "A") {
                action = temp;
            }
        }
        if (floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getHP() <= 0)
        {
            isLost();
            break;
        }
        string command;
        cout << "Race: " << floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getName() << " Gold: " << getGold() << endl;
        cout << "HP: " << floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getHP() << endl;
        cout << "Atk: " << floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getAP() << endl;
        cout << "Def: " << floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getDP() << endl;
        if (firstMove)
        {
            cout << "Action: Player character has spawned." << endl;
        }
        else
        {
            cout << "Action: " << action << endl;
        }

        if (floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getName() == "Troll") {
            floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->setHP(5);
        }

        cin >> command;
        firstMove = false;
        if (command == "no" || command == "so" || command == "ea" || command == "we" || command == "ne" || command == "nw" || command == "se" || command == "sw")
        {

            if (processCmdMovement(command))
            {
                if (command == "no")
                    command = "North";
                else if (command == "so")
                    command = "South";
                else if (command == "ea")
                    command = "East";
                else if (command == "we")
                    command = "West";
                else if (command == "ne")
                    command = "North-East";
                else if (command == "nw")
                    command = "North-West";
                else if (command == "se")
                    command = "South-East";
                else if (command == "sw")
                    command = "South-West";
                if (floors[currentFloor].isStaircase())
                {
                    int changeHP = floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->getHP() - maxHP;
                    action = "PC moves " + command + " and goes to the next level!";
                    currentFloor += 1;
                    floors[currentFloor].data[floors[currentFloor].playerPos.first][floors[currentFloor].playerPos.second]->setHP(changeHP);
                }
                else if (floors[currentFloor].lookForPotion())
                {
                    action = "PC moves " + command + " and sees an unknown potion.";
                }
                else
                {
                    action = "PC moves " + command;
                }
            }
            else
            {
                action = "invalid movement";
            }
            if (canEnemiesMove)
            {
                floors[currentFloor].moveEnemiesRandomly();
            }
        }
        else if (command == "u")
        {
            string direction;
            cin >> direction;
            action = floors[currentFloor].usePotion(direction);
            if (canEnemiesMove)
                floors[currentFloor].moveEnemiesRandomly();
        }
        else if (command == "a")
        {
            string direction;
            cin >> direction;

            
            if(floors[currentFloor].attackedMerchant(direction)) {
                isHated = true;
            }    

            action = floors[currentFloor].goFight(direction, 0);

            if (canEnemiesMove)
                floors[currentFloor].moveEnemiesRandomly();

            
        }
        else if (command == "f")
        {

            canEnemiesMove = !canEnemiesMove;
            if (canEnemiesMove)
            {
                action = "Enemies can move!";
            }
            else
            {
                action = "Enemies are frozen!";
            }
        }
        else if (command == "r")
        {
            srand(time(0));
            Game g = Game{};
            g.runGame();
        }

        else if (command == "q")
        {
            break;
        }
        else
        {
            action = "Invalid command";
        }
    }
}