#ifndef GAME_H
#define GAME_H

#include "component.h"
#include "floor.h"

class Game
{
    int gold = 0;
    Floor f;
    vector<Floor> floors;
    int currentFloor;
    bool canEnemiesMove;
    bool isHated;

public:
    Game();
    void runGame();
    int getGold();
    void setGold(int goldAmount);
    bool processCmdMovement(const std::string &command);
    void nextFloor();
    void isWon();
    void isLost();
};

#endif