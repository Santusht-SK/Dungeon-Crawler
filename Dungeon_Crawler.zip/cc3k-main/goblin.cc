#include "goblin.h"

Goblin::Goblin() : Character(110, 15, 20, "Goblin")
{
    this->displayName = '@';
}

int Goblin::att(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(this->AP * 100 / (100 + enemy->getDP()));
        enemy->setHP(-1 * damage);
        return enemy->getHP();
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of
  // pick up gold, modify setttings.

int Goblin::getAtt(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(enemy->getAP() * 100 / (100 + this->DP));
        string enemyName = enemy->getName();
        if (enemyName == "orc")
        {
            damage = ceil(damage * 1.5);

        } // orc does 50% more damage to goblins
        this->setHP(-1 * damage);
        return damage;
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} //