#include "halfling.h"

Halfling::Halfling() : Character(100, 15, 20, "halfling")
{
    this->displayName = 'L';
}