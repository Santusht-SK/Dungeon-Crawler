#ifndef HALFLING
#define HALFLING
#include "component.h"
#include "character.h"

class Halfling: public Character {
    public:
        Halfling(); // default constructor
};


#endif

