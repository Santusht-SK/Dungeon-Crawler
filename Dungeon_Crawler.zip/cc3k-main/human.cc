#include "human.h"


Human::Human() : Character(140, 20, 20, "human")
{
    this->displayName = 'H';
}