#ifndef HUMAN
#define HUMAN
#include "component.h"
#include "character.h"

class Human: public Character {
    public:
        Human(); // default constructor
};




















#endif
