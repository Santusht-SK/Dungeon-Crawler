#include <iostream>
#include "floor.h"
#include "game.h"
using namespace std;

int main(int argc, char *argv[]) {
    unsigned int seed;
    string seedInput = "";
    if (argc > 1) {
        seed = stoi(argv[1]);
        srand(seed);
    }

    else {
        srand(time(0));
    }
    Game g = Game{};
    g.runGame();
    /*
   
    std::ifstream file("emptyfloor.txt");
    Floor f(file);
    f.spawnEnemies();
    f.createGold();
    f.createPotions();
    f.createStairs();
    f.printFloor();
    f.moveEnemiesRandomly();
    f.printFloor();
     */


 
    
    return 0;
}