#include "merchant.h"

Merchant::Merchant() : Character(30, 70, 5, "merchant")
{
    this->displayName = 'M';
}