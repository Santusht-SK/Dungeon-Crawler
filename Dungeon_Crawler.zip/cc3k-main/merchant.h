#ifndef MERCHANT
#define MERCHANT
#include "component.h"
#include "character.h"

class Merchant: public Character {
    public:
        Merchant(); // default constructor
};






#endif

