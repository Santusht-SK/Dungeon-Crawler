#include "orc.h"

Orc::Orc() : Character(180, 30, 25, "orc")
{
    this->displayName = 'O';
}