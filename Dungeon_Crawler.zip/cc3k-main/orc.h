#ifndef ORC
#define ORC
#include "component.h"
#include "character.h"


class Orc: public Character {
    public: 
        Orc();
};



#endif



