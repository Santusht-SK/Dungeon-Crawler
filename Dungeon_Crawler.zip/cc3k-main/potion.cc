#include "potion.h"

Potion::Potion(string name) : Component(name) {
    this->displayName = 'P';
}

