#ifndef POTION_H
#define POTION_H

#include "component.h"
#include <string>
using namespace std;


class Potion: public Component {
    public:
        Potion(string name); // default constructor
};



#endif


