#include "troll.h"

Troll::Troll() : Character(120, 25, 15, "Troll")
{
    this->displayName = '@';
}

int Troll::att(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(this->AP * 100 / (100 + enemy->getDP()));
        enemy->setHP(-1 * damage);
        return enemy->getHP();
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of
  // pick up gold, modify setttings.

int Troll::getAtt(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(enemy->getAP() * 100 / (100 + this->DP));
        this->setHP(-1 * damage);
        return damage;
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // get attack only called when enemy didnt miss, the random miss function should be judged by main.cc