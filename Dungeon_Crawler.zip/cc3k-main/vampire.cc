#include "vampire.h"

Vampire::Vampire() : Character(50, 25, 25, "Vampire")
{
    this->displayName = '@';
}

int Vampire::att(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(this->AP * 100 / (100 + enemy->getDP()));
        enemy->setHP(-1 * damage);
        string enemyName = enemy->getName();
        if (name != "dwarf")
        {
            this->setHP(5); // increase vampire HP by 5 in every succeful attack
        }
        else
        {
            this->setHP(-5); // vampire is allergic to dwarf
        }
        return enemy->getHP();
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of
  // pick up gold, modify setttings.

int Vampire::getAtt(Component *enemy)
{
    if (enemy)
    {
        int damage = ceil(enemy->getAP() * 100 / (100 + this->DP));
        this->setHP(-1 * damage);
        return damage;
    }
    else
    {
        cout << "bad dynamic cast for" + enemy->getName() << endl;
        return -1;
    }
} // get attack only called when enemy didnt miss, the random miss function should be judged by main.cc