#ifndef Vampire_H
#define Vampire_H
#include "component.h"
#include "character.h"
#include <cmath>
#include <iostream>
using namespace::std;

class Vampire: public Character {
    public:
        Vampire();

        int att(Component* enemy);
        // att will only be in charge of modify enemy's HP and return enemy's Hp after attack, main loop will be in charge of 
        // pick up gold, modify setttings.

        int getAtt(Component* enemy);

};


#endif

